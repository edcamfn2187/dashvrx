export const DEFAULT_CLIENT = 'GUIDONI';
export const CLIENTS_LIST = ['GUIDONI', 'LOCAL_INSTANCE'];
export const API_BASE = '/api';
export const CONFIG_API_BASE = '/api/config';
export const DEFAULT_VERSION = '4.0.1 Stable';
export const DEFAULT_OWNER = 'MSS Application Security';
export const DEFAULT_CLASSIFICATION = 'CONFIDENCIAL';