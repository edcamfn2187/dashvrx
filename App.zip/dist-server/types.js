export var Page;
(function (Page) {
    Page["HOME"] = "home";
    Page["SETTINGS"] = "settings";
    Page["DIAGNOSTICS"] = "diagnostics";
    Page["DATABASE_EXPLORER"] = "database_explorer";
})(Page || (Page = {}));
